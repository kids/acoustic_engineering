#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Tests for opuslib."""

__author__ = 'Никита Кузнецов <self@svartalf.info>'
__copyright__ = 'Copyright (c) 2012, SvartalF'
__license__ = 'BSD 3-Clause License'
